<?php
/*
Plugin Name: My  Plugin
Description: Это мой плагин! Он создаёт отдельную админ-ссылку!
Author: Кравченко
*/

// Подключаем functions.php, используя require_once, чтобы остановить скрипт, если mfp-functions.php не найден
require_once plugin_dir_path(__FILE__) . 'includes/functions.php';